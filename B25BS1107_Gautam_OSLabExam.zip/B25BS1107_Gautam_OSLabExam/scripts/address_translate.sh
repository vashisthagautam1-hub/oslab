#!/bin/bash

read -r -p 'Enter page size: ' page_size
read -r -p 'Enter logical address: ' logical_address
if [[ ! $page_size =~ ^[0-9]+$ ]] || (( page_size < 1 )) ||
    [[ ! $logical_address =~ ^[0-9]+$ ]]; then
    printf 'Invalid input\n'
    exit 1
fi

declare -A page_table=([0]=3 [1]=6 [2]=1 [3]=7)
page_number=$((logical_address / page_size))
offset=$((logical_address % page_size))
if [[ ! -v page_table[$page_number] ]]; then
    printf 'Page Fault: invalid page\n'
    exit 0
fi

frame_number=${page_table[$page_number]}
physical_address=$((frame_number * page_size + offset))
printf 'Page: %d\nOffset: %d\nFrame: %d\nPhysical address: %d\n' \
    "$page_number" "$offset" "$frame_number" "$physical_address"