#!/bin/bash

if [[ $# -lt 1 ]]; then
    printf 'Usage: ./perm_check.sh <filename>\n'
    exit 1
fi

file=$1
if [[ ! -e $file ]]; then
    printf 'File not found\n'
    exit 1
fi

permission=$(stat -c '%a' -- "$file") || exit 1
printf 'File: %s\n' "$file"
printf 'Permission: %s\n' "$permission"

case $permission in
    600|700) printf 'Status: PRIVATE\n' ;;
    644) printf 'Status: SHARED-READ\n' ;;
    *) printf 'Status: REVIEW\n' ;;
esac