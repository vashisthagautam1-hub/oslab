#!/bin/bash

read -r -p 'Enter number of processes: ' process_count
if [[ ! $process_count =~ ^[0-9]+$ ]] || (( process_count < 1 )); then
    printf 'Invalid number of processes\n'
    exit 1
fi

declare -a arrivals bursts
for ((index = 0; index < process_count; index++)); do
    read -r -p "Enter arrival and burst time for P$((index + 1)): " arrivals[index] bursts[index]
done

printf '%-10s %5s %5s %8s %5s %5s\n' Process AT BT Finish TAT WT
clock=0
total_waiting=0
total_turnaround=0
for ((index = 0; index < process_count; index++)); do
    if (( clock < arrivals[index] )); then
        clock=${arrivals[index]}
    fi
    start=$clock
    finish=$((start + bursts[index]))
    turnaround=$((finish - arrivals[index]))
    waiting=$((start - arrivals[index]))
    printf '%-10s %5d %5d %8d %5d %5d\n' "P$((index + 1))" \
        "${arrivals[index]}" "${bursts[index]}" "$finish" "$turnaround" "$waiting"
    total_waiting=$((total_waiting + waiting))
    total_turnaround=$((total_turnaround + turnaround))
    clock=$finish
done

awk -v waiting="$total_waiting" -v turnaround="$total_turnaround" \
    -v count="$process_count" 'BEGIN {
        printf "Average waiting time: %.2f\n", waiting / count
        printf "Average turnaround time: %.2f\n", turnaround / count
    }'